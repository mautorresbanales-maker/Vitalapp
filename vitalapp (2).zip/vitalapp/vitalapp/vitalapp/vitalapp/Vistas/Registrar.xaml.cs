using Microsoft.Maui.Controls;
using System;
using System.Threading.Tasks;
using Microsoft.Maui.Storage;

namespace vitalapp.Vistas;

public partial class Registrar : ContentPage
{
	public Registrar()
	{
		InitializeComponent();
	}

    private async void TapGestureRecognizer_Tapped(object sender, TappedEventArgs e)
    {
        Application.Current.MainPage = new NavigationPage(new LoginPage());
    }

    private async void RegisterButton_Clicked(object sender, EventArgs e)
    {
        // 1. Limpiar mensajes previos
        MessageLabel.IsVisible = false;
        MessageLabel.Text = string.Empty;

        // 2. Obtener valores
        string usuario = UsernameEntry.Text?.Trim();
        string contrasena = PasswordEntry.Text;
        string confirmarContrasena = ConfirmPasswordEntry.Text;

        // 3. Validaci�n de campos
        if (string.IsNullOrWhiteSpace(usuario) || string.IsNullOrWhiteSpace(contrasena))
        {
            MostrarMensaje("Los campos Usuario y Contrase�a son obligatorios.", true);
            return;
        }

        if (contrasena != confirmarContrasena)
        {
            MostrarMensaje("Las contrase�as no coinciden. Intente de nuevo.", true);
            PasswordEntry.Text = string.Empty;
            ConfirmPasswordEntry.Text = string.Empty;
            return;
        }

        // 4. Guardar credenciales usando Preferences
        Preferences.Set("RegisteredUser", usuario);
        Preferences.Set("RegisteredPassword", contrasena);
        UsernameEntry.Text = string.Empty;
        EmailEntry.Text = string.Empty;
        PasswordEntry.Text = string.Empty;
        ConfirmPasswordEntry.Text = string.Empty;

        // 5. Registro exitoso
        MostrarMensaje("�Registro exitoso! Ahora puedes iniciar sesi�n.", false);

        // Breve espera para mostrar el mensaje
        await Task.Delay(1500);

        // Volver al login
        Application.Current.MainPage = new NavigationPage(new LoginPage());
    }
    

    private void MostrarMensaje(string mensaje, bool esError)
    {
        MessageLabel.Text = mensaje;
        MessageLabel.TextColor = esError ? Color.FromArgb("#FF0000") : Color.FromArgb("#008000");
        MessageLabel.IsVisible = true;
    }
}


