namespace vitalapp.Vistas;

public partial class RegReceta : ContentPage
{
	public RegReceta()
	{
		InitializeComponent();
	}
}