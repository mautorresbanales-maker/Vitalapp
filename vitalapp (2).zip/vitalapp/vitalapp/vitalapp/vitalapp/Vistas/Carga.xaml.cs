namespace vitalapp.Vistas;

public partial class Carga : ContentPage
{
	public Carga()
	{
		InitializeComponent();
	}

    protected async override void OnNavigatedTo(NavigatedToEventArgs args)
    {
        base.OnNavigatedTo(args);
        await Task.Delay(2000);
        await Shell.Current.GoToAsync($"//{nameof(LoginPage)}");
    }
}