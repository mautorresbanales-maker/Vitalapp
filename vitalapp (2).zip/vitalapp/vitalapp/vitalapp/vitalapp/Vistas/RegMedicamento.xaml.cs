using System.Threading.Tasks;

namespace vitalapp.Vistas;

public partial class RegMedicamento : ContentPage
{
	public RegMedicamento()
	{
		InitializeComponent();
	}

    private async Task Button_Clicked(object sender, EventArgs e)
    {
	
    }
}