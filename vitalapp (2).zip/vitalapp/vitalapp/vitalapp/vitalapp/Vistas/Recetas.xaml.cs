namespace vitalapp.Vistas;

public partial class Recetas : ContentPage
{
	public Recetas()
	{
		InitializeComponent();
	}

    private async void Button_Clicked(object sender, EventArgs e)
    {
		await Navigation.PushAsync(new RegReceta());
    }
}