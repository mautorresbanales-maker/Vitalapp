using vitalapp.VistaModelo;
using Microsoft.Maui.Storage;
namespace vitalapp.Vistas;

public partial class LoginPage : ContentPage
{
    LoginVistaModelo vml;
    public LoginPage()
	{
        vml = new LoginVistaModelo();
        InitializeComponent();
        BindingContext = vml;
    }

    private async void TapGestureRecognizer_Tapped(object sender, TappedEventArgs e)
    {
        Application.Current.MainPage = new NavigationPage(new Registrar());

    }

    private async void LoginButton_Clicked(object sender, EventArgs e)
    {
        string usuario = vml.Usuario;
        string contrase�a = vml.Contrase�a;

        if (string.IsNullOrWhiteSpace(usuario) || string.IsNullOrWhiteSpace(contrase�a))
        {
            await DisplayAlert("Error", "Debe ingresar usuario y contrase�a.", "OK");
            return;
        }

        
        string usuarioRegistrado = Preferences.Get("RegisteredUser", string.Empty);
        string contrasenaRegistrada = Preferences.Get("RegisteredPassword", string.Empty);

        if (string.IsNullOrEmpty(usuarioRegistrado) || string.IsNullOrEmpty(contrasenaRegistrada))
        {
            await DisplayAlert("Registro requerido",
                "No existe un usuario registrado.\nPor favor reg�strese antes de iniciar sesi�n.",
                "OK");

            Application.Current.MainPage = new NavigationPage(new Registrar());
            return;
        }

      
        if (!usuario.Equals(usuarioRegistrado, StringComparison.OrdinalIgnoreCase) ||
            contrase�a != contrasenaRegistrada)
        {
            await DisplayAlert("Error",
                "Usuario o contrase�a incorrectos.",
                "OK");
            return;
        }

       

        vml.Usuario = string.Empty;
        vml.Contrase�a = string.Empty;
        await DisplayAlert("Bienvenido", "Inicio de sesi�n exitoso.", "OK");

        Application.Current.MainPage = new NavigationPage(new Principal());
    }
}

