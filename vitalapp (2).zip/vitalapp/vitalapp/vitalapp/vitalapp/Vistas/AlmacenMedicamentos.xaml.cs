using System.Threading.Tasks;

namespace vitalapp.Vistas;

public partial class AlmacenMedicamentos : ContentPage
{
	public AlmacenMedicamentos()
	{
		InitializeComponent();
	}

    private async void Button_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new RegMedicamento());
    }
}