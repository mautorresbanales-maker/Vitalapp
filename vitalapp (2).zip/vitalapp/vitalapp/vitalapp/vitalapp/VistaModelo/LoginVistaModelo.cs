﻿using vitalapp.Vistas;
using System.ComponentModel;
using System.Windows.Input;
using Microsoft.Maui.Controls;
using Microsoft.Maui.Storage;
namespace vitalapp.VistaModelo
{
    public class LoginVistaModelo : INotifyPropertyChanged
    {
        private string usuario;
        public string Usuario
        {
            get => usuario;
            set
            {
                usuario = value?.Trim();
                AlCambiarPropiedad(nameof(Usuario));
            }
        }

        private string contraseña;
        public string Contraseña
        {
            get => contraseña;
            set
            {
                contraseña = value; 
                AlCambiarPropiedad(nameof(Contraseña));
            }
        }

        
        public ICommand IniciarSesion => new Command(
            async () =>
            {
                
                if (string.IsNullOrEmpty(Usuario) || string.IsNullOrEmpty(Contraseña))
                {
                    await Application.Current.MainPage.DisplayAlert(
                        "Error de Acceso",
                        "Por favor, ingrese el usuario y la contraseña.",
                        "Aceptar");
                    return;
                }

                
                string usuarioRegistrado = Preferences.Get("RegisteredUser", string.Empty);
                string contrasenaRegistrada = Preferences.Get("RegisteredPassword", string.Empty);

                
                bool usuarioCoincide = Usuario.Equals(usuarioRegistrado, StringComparison.OrdinalIgnoreCase);
                bool contrasenaCoincide = Contraseña == contrasenaRegistrada;

                if (usuarioCoincide && contrasenaCoincide)
                {
                    Usuario = string.Empty;
                    Contraseña = string.Empty;
                    await Application.Current.MainPage.DisplayAlert(
                        "¡Bienvenido!",
                        "Inicio de sesión exitoso.",
                        "OK");

                    Application.Current.MainPage = new NavigationPage(new Principal());
                }
                else
                {
                    Contraseña = string.Empty;
                    await Application.Current.MainPage.DisplayAlert(
                        "Error de Acceso",
                        "Usuario o contraseña incorrectos. Si no tiene una cuenta, regístrese.",
                        "Aceptar");

                    
                }
            }
        );

        
        public ICommand CerrarSesion => new Command(
            async () =>
            {
                Usuario = string.Empty;
                Contraseña = string.Empty;
                Application.Current.MainPage = new NavigationPage(new LoginPage());
            }
        );

       
        public event PropertyChangedEventHandler PropertyChanged;
        public void AlCambiarPropiedad(string propiedad)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propiedad));
        }
    }
}



